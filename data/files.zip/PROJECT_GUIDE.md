# Excel Practice Projects — Demographic/Social Data

Three datasets, three different real-analyst skills. Do them in order.

---

## Project 1: Data Cleaning — Household Survey
**File:** `project1_household_survey_raw.csv`

### Tasks

**Deliverable:** a clean version of this file, plus a short note (5-6 bullet points) listing every issue you found and how you fixed it.

---

## Project 2: Aggregation & Dashboard-Ready Table 
**File:** `project2_population_by_lga.csv` 


### Tasks
1. **Total population by state.
2. Build a **population pyramid** for Lagos state (age group × sex, split male/female)
3. Calculate **urban vs rural population share** per state.
4. Calculate the **dependency ratio** per state. 
5. Produce **one summary table** that could go straight into a dashboard: state, total population, % urban, dependency ratio, sorted by population descending.

---

## Project 3: Trend Analysis + Written Insight 
**File:** `project3_social_indicators_2015_2023.csv` 

State-level literacy rate, fertility rate, under-5 mortality, and primary
school enrolment, 2015–2023.

### Tasks
1. Build a **line chart** of literacy rate over time for Lagos, Kaduna, Kano and Rivers state.
2. Calculate **% change 2015 → 2023** for each indicator, by state.
3. Find the **correlation** between literacy rate and under-5 mortality across states.
4. Rank states by **most improved** primary school enrolment.
5. Which states are improving fastest on social indicators, and which are lagging — and what's one hypothesis for why?

---

## Project 4: Statistical Inference
**File:** reuse your **cleaned** version of `project1_household_survey_raw.csv`


### Tasks
1. **mean, median, std dev, skewness of `age` and `monthly_income_naira`, overall and by state.
2. **build a 95% CI for mean monthly income, overall and for Lagos state.
3. **is there a statistically significant difference in mean income between men and women in this data? 
4. **is `education_level` associated with `employment_status`? 
5. **does `education_level predict `monthly_income_naira`? Report R², the coefficient, and why this doesn't prove causation.
6. **Write on what population this sample would need to represent to generalize your t-test/regression results, and what could bias it.
